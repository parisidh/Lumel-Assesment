import { useState } from 'react'
import HierarchicalTable from './HeirarchicalTable'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
       <HierarchicalTable data={data} />
    </>
  )
}

export default App
