import React, { useState } from 'react';

function HierarchicalTable({ data }) {
  const [tableData, setTableData] = useState(data);

  const handleInputChange = (id, value) => {
    setTableData(prevData => {
      const updatedData = [...prevData];
      const node = updatedData.find(item => item.id === id);
      node.value = value;
      return updatedData;
    });
  };

  const handleAddChild = (parentId) => {
    setTableData(prevData => {
      const updatedData = [...prevData];
      const parentNode = updatedData.find(item => item.id === parentId);
      parentNode.children.push({ id: Date.now(), label: 'New Child', value: 0 });
      return updatedData;
    });
  };

  const handleRemoveChild = (parentId, childId) => {
    setTableData(prevData => {
      const updatedData = [...prevData];
      const parentNode = updatedData.find(item => item.id === parentId);
      parentNode.children = parentNode.children.filter(item => item.id !== childId);
      return updatedData;
    });
  };

  const renderTable = (data) => {
    return (
      <table>
        <thead>
          <tr>
            <th key="label">Label
              <th>Electronics</th>
              <td>--phones</td>
            </th>
            <th key="value"></th>
            <th>input</th>
            <th>Allocation%</th>
            <th>Allocation val</th>
            <th>Variance %</th>
          </tr>
        </thead>
        <tbody>
       {data.map(item => (
            <tr key={item.id}>
              <td>{item.label}</td>
              <td><input type="number" value={item.value} onChange={(e) => handleInputChange(item.id, e.target.value)} /></td>
              <td>
                <button onClick={() => handleAddChild(item.id)}>Add Child</button>
                {item.children && item.children.length > 0 && (
                  <button onClick={() => handleRemoveChild(item.id, item.children[item.children.length - 1].id)}>Remove Child</button>
                )}
              </td>
              {item.children && renderTable(item.children)}
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  return (
    <div>
      {renderTable(tableData)}
    </div>
  );
}

export default HierarchicalTable;